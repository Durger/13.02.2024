import java.lang.annotation.*;

//Задача
//Создать анотацию, в которой должно быть 2 значения по умолчанию и эти значения должны быть числовым
//Создайте класс с этой анотацией в классе с функцией, которая принимает 2 целых числа и складывает их с числом объетов этого класса
//и умножает на число из поля этого класса.
//Дочерний класс, который будет с функцией делением суммы чисел вместо умножения
@Inherited//можно пользоваться в классах наследниках класса над которым обращаемся к анотации
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@interface Numbers{
   int one () default  2;
    int two () default  5;
}

@Numbers
class MultiplicationNumbers{
    int one;

    public MultiplicationNumbers(int one){
        this.one = one;

    }
   public  void Calculator (int a, int b){
       int c;
       c = (a + b) * one;
       System.out.println("Умножение: " + c);
   }
}

class Сalculator extends MultiplicationNumbers {

    public Сalculator(int one) {
        super(one);
    }
    public  void Calculator1 (int a, int b){
        int c;
        c = (a + b) / one;
        System.out.println("Деление: " + c);
    }
}

public class Main {
    public static void main(String[] args) {
        MultiplicationNumbers M1 = new MultiplicationNumbers(10);
        Annotation companyAnatation = M1.getClass().getAnnotation(Numbers.class);
        Numbers company = (Numbers) companyAnatation;
        M1.Calculator(company.one(),company.two());

        Calculator1 M2 = new Calculator1(10);
        Annotation companyAnatation = M1.getClass().getAnnotation(Numbers.class);
        Numbers company = (Numbers) companyAnatation;
        M2.Calculator(company.one(),company.two());


    }
}