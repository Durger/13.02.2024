// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Human human = new Human( "Александр Сергеевич", 22,  2154578, "Petersburg",
                "Russia", "Nevskiy");
        System.out.println(human.toString ());

        //Scanner scanner = new Scanner(System.in);
        //System.out.println("Введите фамилию");
        //String info = scanner.nextLine();
        //System.out.println(info);

        //Scanner scanner = new Scanner(System.in);
        //System.out.println("Возраст");
        //String info = scanner.nextLine();
        //System.out.println(info);

        }
    }
