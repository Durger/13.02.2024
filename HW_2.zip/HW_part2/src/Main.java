import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.util.stream.IntStream;

import static java.util.Collections.sort;


public class Main {
    public static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        task1();
    }

    public static void task1() {
        //  Задание.1.Вывести построчно в консоль слова Стива Джобса
        System.out.println("Your time is limited");
        System.out.println("so don’t waste it");
        System.out.println("living someone else’s life");
    }

    public static void task2() {
        // Задание.2. Посчитать процент от числа
        System.out.print("Введите число от которого нужно посчитать процент: ");
        int a = scan.nextInt();
        System.out.println("Введите для расчета размер процента от первоначальногно числа");
        int b = scan.nextInt();
        System.out.println("Сумма процентов:" + a * b / 100);
    }

    public static void task3() {
        // Задание.3. Ввести 3 отдельные цифры и сложить в одно число.
        System.out.print("Введите первое число, которое нужно сложить: ");
        int d = scan.nextInt();
        System.out.print("Введите второе число, которое нужно сложить: ");
        int f = scan.nextInt();
        System.out.print("Введите третье число, которое нужно сложить: ");
        int g = scan.nextInt();
        int result = d + f + g;
        System.out.println("Сумма трех чисел: " + result);
    }

    public static void task4() {
        // Задача.4.Переворот шестизначного числа + провека количества символов (Не работает проверка)
        System.out.println("Введите шестизначное число: ");
        int numberToReverse = scan.nextInt();
        int numDigits = (int)Math.log10(numberToReverse) + 1;
        if (numDigits > 6 || numDigits < 6)
        {
            System.out.println("Вы ввели не шестизначное число");
        }
        StringBuilder builder = new StringBuilder(String.valueOf(numberToReverse));
        builder.reverse();
        System.out.println("Число наоборот " + builder);
    }

    public static void task5() {
// Задача.5.Ввод значений и проверка на соответсвия изх временам года.
        System.out.println("Введите порядковый номер месяца календарного года");
        int month = scan.nextInt();
        if (month == 1 || month == 2 || month == 12) {
            System.out.println("Winter");
        }
        if (month == 3 || month == 4 || month == 5) {
            System.out.println("Spring");
        }
        if (month == 6 || month == 7 || month == 8) {
            System.out.println("Summer");
        }
        if (month == 9 || month == 10 || month == 11) {
            System.out.println("Winter");
        }
        if (month < 1 || month > 12) {
            System.out.println("УНИКУМ!!!! Ты указал не существующий календарный месяц!!!");
        }
    }

    public static void task6() {
        // Задача.6. Написать программу конвертации величин метрической системы.
        System.out.println("Введите количество метров для конвертации длинны");
        int lengthM = scan.nextInt();
        System.out.println("Выберете величину длинны для преобразования: 1 - Мили, 2 - Дюймы, 3 - Ярды");
        int magnitude = scan.nextInt();
        if (magnitude < 1 || magnitude > 3) {
            System.out.println("УНИКУМ!!!! Ты прочитал не внимательно варианты для выбора, попробуй снова!!!");
        }
        double miles = 1;
        //miles = 0.00062137;
        double Inches = 2;
        //Inches = 39.3701;
        double ayrds = 3;
        // ayrds = 1.0936;
        if (magnitude == 1) {
            double result1 = (int) lengthM * 0.00062137;
            System.out.println("Величина в милях равна = " + result1);
        }
        if (magnitude == 2) {
            double result2 = (int) lengthM * 39.3701;
            System.out.println("Величина в дюймах равна = " + result2);
        }
        if (magnitude == 3) {
            double result3 = (int) lengthM * 1.0936;
            System.out.println("Величина в ярдах равна = " + result3);
        }
    }

    public static void task7() {
        // Задача.7. Показать четные и не четные двухзначные числа из двух введенных пользователем и выстроить их.
        //-Ввоод 1го числа и проверка на двухзначность, Вввод 2-го числа и проверка на двухзначность,
        System.out.println("Введите первое двухзначное число");
        int twoNum1 = scan.nextInt();
        if (twoNum1 < 10 || twoNum1 > 99) {
            System.out.println("Вы ввели не двухзначное число");
        }
        System.out.println("Введите второе двухзначное число");
        int twoNum2 = scan.nextInt();
        if (twoNum2 < 10 || twoNum2 > 99) {
            System.out.println("Вы ввели не двухзначное число");
        }
        // - Если условие выполняется, то идет сравнение двух переменных друг с другом для выстраивания в ряд.
        if (twoNum2 < twoNum1) {
            int newTwoNum1 = twoNum2;
            int newTwoNum2 = twoNum1;
            System.out.println("Диапазон вычислений начинается с: " + newTwoNum1 + " " + "до: " + newTwoNum2);
            for (int q = newTwoNum1; q <= newTwoNum2; q++) {
                if (q % 2 != 0)
                    System.out.println(" Нечетные числа в диапазон вычислений : " + q);
            }
        }
        // Если первоначально первое число меньше второго, то выполняется расчет без нормализации
        for (int i = twoNum1; i <= twoNum2; i++) {
            if (i % 2 != 0)
                System.out.println(" Нечетные числа в диапазон вычислений : " + i);
        }
    }

    public static void task8() {
// Задача.8.Показать на экране таблицу умножения в диапазоне, указанным пользователем.
        //-Ввоод 1го числа, Вввод 2-го числа,Ввод максимального диапазона для каждого из чисел
        System.out.println("Введите первое однозначное число таблицы умножения: ");
        int twoNum1 = scan.nextInt();
        System.out.println("Введите максимальный диапазон для умножения первого числа: ");
        int maxNum1 = scan.nextInt();
        System.out.println("Введите второе однозначное число таблицы умножения: ");
        int twoNum2 = scan.nextInt();
        System.out.println("Введите максимальный диапазон для умножения второго числа: ");
        int maxNum2 = scan.nextInt();
        // Цикл для расчета первого числа
        for (int i = 0; i <= maxNum1; i++) {
            int result = twoNum1 * i;
            System.out.println("Таблица умножения первого числа : " + twoNum1 + "*" + i + "=" + result);
        }
        // Цикл для расчета второго числа
        for (int i = 0; i <= maxNum2; i++) {
            int result = twoNum2 * i;
            System.out.println("Таблица умножения второго числа : " + twoNum1 + "*" + i + "=" + result);
        }
    }

    public static void task9() {
// Задача.9.В одномерном массиве, заполненном случайными числами определить минимальные и максимальные элементы.
// Посчитать колличество отрицательных и положительных элементов, а также колличество нулей с выводом результатов на экран.

//Создать одномерный массив, заполненный случайными числами
        int[] mas = new int[15];
        for (int i = 0; i < mas.length; i++) {
            mas[i] = (int) (Math.random() * 10);
            System.out.println("Массив, заполненный случайными числами: " + mas[i]);
        }
        // Определение минимальных и максимальных элементов. Для простого определения минимального и максимальногог значения -
        //отсортировать и взять из массива первое и последнее значение.
        Arrays.sort(mas);
        System.out.println("Отсортированный массив с случайными числами: " + Arrays.toString(mas));
        System.out.println("Минимальный элемент массива: " + (mas[0]));
        System.out.println("Максимальный элемент массива: " + (mas[14]));

        // Посчитать колличество отрицательных и положительных элементов, а также колличество нулей
        //Инициплизация переменных-счетчиков и присвоение им начального занчения 0
        int positiveCount, negativeCount, zeroCount;
        positiveCount = negativeCount = zeroCount = 0;
        for (int i = 0; i < mas.length; i++) {
            //Условие для поиска положительных значений и их подсчет
            if (mas[i] > 0) {
                positiveCount++;
            } else if (mas[i] < 0) {
                //Условие для поиска отрицательных значений и их подсчет
                negativeCount++;
            } else if (mas[i] == 0) {
                //Условие для поиска нулевых значений и их подсчет
                zeroCount++;
            }
        }
        System.out.println("Подсчет положительных элементов массива: " + positiveCount);
        System.out.println("Подсчет отрицательных элементов массива: " + negativeCount);
        System.out.println("Подсчет нолей в массиве: " + zeroCount);
    }

    public static void task10() {
        // Задача.10. Создать одномерный массив, заполненный случайными числами.
        //На основании данных массива:
        // - Создать одномерный массив, содержащий только четные числа из первого массива;
        // - Создать одномерный массив, содержащий только нечетные числа из первого массива;
        // - Создать одномерный массив, содержащий только отрицательные числа из первого массива;
        // - Создать одномерный массив, содержащий только положительные числа из первого массива.

        //Создание одномерного массива, заполненного случайными числами
        int[] mas = new int[10];
        for (int i = 0; i < mas.length; i++) {
            mas[i] = (int) (Math.random() * 7);
            Arrays.sort(mas);
            System.out.println("Массив, заполненный случайными числами: " + mas[i]);
        }
        // Создание одномерного массива, содержащего только четные числа из первого массива;
        Arrays.sort(mas);
        for (int i = 0; i < mas.length; i++) {
            if (mas[i] % 2 == 0 && mas[i] != 0)
                System.out.println("Четные числа в массиве с случайными числами : " + mas[i]);
        }
        // Создание одномерного массива, содержащего только не четные числа из первого массива;
        for (int i = 0; i < mas.length; i++) {
            if (mas[i] % 2 != 0 && mas[i] != 0)
                System.out.println("Нечетные числа в массиве с случайными числами : " + mas[i]);
        }
        // Создание одномерного массива, содержащего только отрицательные числа из первого массива;
        for (int i = 0; i < mas.length; i++) {
            if (mas[i] < 0)
                System.out.println("Отрицательные числа в массиве с случайными числами : " + mas[i]);
        }
        // Создание одномерного массива, содержащего только положительные числа из первого массива;
        for (int i = 0; i < mas.length; i++) {
            if (mas[i] > 0 && mas[i] != 0)
                System.out.println("Положительные числа в массиве с случайными числами : " + mas[i]);
        }

    }
    //11. Напишите метод, который отображает горизонтальную или вертикальную линию из некоторого символа.
    //Метод принимает в качестве параметра: длину линии. направление, символ.
    public static void task11() {
        Task11.displayingALineFromASymbol();
    }
    //12. Напишите метод, сортирующий массив по убыванию или возрастанию в зависимости от выбора пользователя.
    public static void task12() {
        Task12.sortArrayToUpAndDown();
    }
}

class Task11 {
    //Напишите метод, который отображает горизонтальную или вертикальную линию из некоторого символа.
    //Метод принимает в качестве параметра: длину линии,направление, символ.
    public static void displayingALineFromASymbol() {
        // Прием символа от пользователя
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите символ для отображения: ");
        char x = scanner.next().charAt(0);  // Без выбора символа char simbol = '@';
       // Прием параметров длинны линии
        System.out.println("Введите длинну линиии из символа: ");
        int length = scanner.nextInt();
        // Прием параметров направления линии (условие горизонталь/вертикаль)
        System.out.println("Выберете направлениие линии: 1 - горизонтальная, 2 - вертикальная");
        int direction = scanner.nextInt();
        // Условие для вывода линии по горизонтали или по вертикали
        if (direction == 1) {
            for (int i = 0; i < length; i++)
                System.out.print(x);
        } else if (direction == 2) {
            for (int i = 0; i < length; i++)
                System.out.println(x);
        } else {
            System.out.println("УНИКУМ!!!! Ты прочитал не внимательно варианты для выбора, попробуй снова!!!");
        }
    }
}
class Task12 {
    //12. Напишите метод, сортирующий массив по убыванию или возрастанию в зависимости от выбора пользователя.
    public static void sortArrayToUpAndDown() {
        //Создать одномерный массив, заполненный случайными числами
        Integer[] mas = new Integer[]{5, 16, 1, 44, 3, 8, 4, 100};
        System.out.println("Массив: " + Arrays.toString(mas));
        System.out.println("Выберете вид сортировки: 1 - по возрастанию, 2 - по убыванию: ");
        Scanner scanner = new Scanner(System.in);
        int direction = scanner.nextInt();
        for (Integer i = 0; i < mas.length; i++)
            if (direction == 1) {
                Arrays.sort(mas);
                System.out.println("Массив, отсортированный по возрастанию: " + Arrays.toString(mas));
            } else if (direction == 2) {
                Arrays.sort(mas, Collections.reverseOrder());
                {
                    System.out.println("Массив, отсортированный по убыванию: " + Arrays.toString(mas));
                }
            } else {
                System.out.println("УНИКУМ!!!! Ты прочитал не внимательно варианты для выбора, попробуй снова!!!");
            }
    }
}
            /*Заметьте, что для использования Collections.reverseOrder(), массив должен быть массивом
        объектов (Integer), а не примитивным массивом (int). Если у вас есть примитивный массив, вам придется
            преобразовать его в массив объектов или написать свой собственный компаратор для сортировки в обратном порядке*/
// array[i] = (int) (Math.random() * 10);


















